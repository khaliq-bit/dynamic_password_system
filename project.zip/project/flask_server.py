from flask import Flask, request, jsonify, render_template, session,  redirect, url_for
from datetime import datetime, timedelta
import hashlib
import re
import requests
import time
import sqlite3
from rocku_dynamic_passwd import is_common_password

# Flask app initialization
app = Flask(__name__)

import re
days_pattern = r"(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)$"
app.secret_key = 'your_secret_key_here'

# To initialize the state in the home page
lock_state = "Locked"

# Database setup
def init_db():
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        username TEXT NOT NULL UNIQUE,
                        hashed_password TEXT NOT NULL,
                        security_question TEXT,
                        security_answer TEXT,
                        algorithm TEXT NOT NULL,
                        time_format TEXT DEFAULT '24'
                    )''')
    conn.commit()
    conn.close()

init_db()

# Function to validate base password requirements
def is_valid_password(password):
    if len(password) < 6:
        return False
    if not re.search(r"[A-Z]", password):
        return False
    if not re.search(r"[a-z]", password):
        return False
    if not re.search(r"[0-9]", password):
        return False
    if not re.search(r"[!@#$%^&*()_+=-]", password):
        return False
    return True

# Function to hash the password
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Function to generate dynamic password
def generate_dynamic_password(base_password, choice, time_format='24'):
    current_time = datetime.now()
    if choice == '1':  # Change every minute
        dynamic_password = f"{base_password}{current_time.minute}"
        next_change = current_time.replace(second=0, microsecond=0) + timedelta(minutes=1)
    elif choice == '2':  # Change every hour
        current_hour = current_time.strftime("%H") if time_format == '24' else current_time.strftime("%I")
        dynamic_password = f"{base_password}{current_hour}"
        next_change = current_time.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
    elif choice == '3':  # Change every day of the week
        dynamic_password = f"{base_password}{current_time.strftime('%A')}"
        next_change = current_time.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=1)
    return dynamic_password, next_change



@app.route('/')
def index():
    return render_template('signup.html')

# Routes
@app.route('/signup', methods=['POST'])
def signup():
    username = request.form.get('username')
    base_password = request.form.get('password')
    security_question = request.form.get('security_question')
    security_answer = request.form.get('security_answer')
    algorithm = request.form.get('algorithm', '1')
    time_format = request.form.get('time_format', '24') 

    if not username or not base_password:
        return jsonify({"error": "Username and password are required."}), 400
        
    if is_common_password(base_password):
        return jsonify({"Warning": "Your password is found in the common passwords list. Please choose a stronger password."}), 400
    else:
        if not is_valid_password(base_password):
            return jsonify({"error": "Password must meet security requirements."}), 400
    

    hashed_password = hash_password(base_password)

    try:
        conn = sqlite3.connect('users.db')
        cursor = conn.cursor()
        cursor.execute("INSERT INTO users (username, hashed_password, security_question, security_answer, algorithm, time_format) VALUES (?, ?, ?, ?, ?, ?)",
                       (username, hashed_password, security_question, security_answer, algorithm, time_format))
        conn.commit()
        conn.close()

        dynamic_password, _ = generate_dynamic_password(base_password, algorithm, time_format)
        return render_template('signup_success.html', username=username, dynamic_password=dynamic_password), 201

    except sqlite3.IntegrityError:
        return jsonify({"error": "Username already exists."}), 409

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        # Render the login page for GET requests
        return render_template('login.html')

    # For POST requests, process the login
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        print(f'username:{username}\n')
        print(password)

    if not username or not password:
        return jsonify({"error": "Both username and password are required."}), 400

    try:
        with sqlite3.connect('users.db') as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT id, hashed_password, algorithm, time_format FROM users WHERE username = ?", (username,))
            row = cursor.fetchone()
            print(row)

        if row:
            session['username'] = username 
            session['id'] = row[0]

            id, stored_hashed_password, algorithm, time_format = row
            print(f'stored_hashed_password: {stored_hashed_password}\nalgorithm: {algorithm}\ntime_format: {time_format}')

            if algorithm == '1' or algorithm =='2' :
                base_password = password[:-2]
                print(f'base_password: {base_password}')

            elif algorithm == '3':
                # Regex to find and remove the day
                base_password = re.sub(days_pattern, "", password, flags=re.IGNORECASE)
                print(f'base_password: {base_password}')
            
            # Validate the base password
            if hash_password(base_password) != stored_hashed_password:
                return jsonify({"error": "Invalid username or password."}), 401

            # Generate the dynamic password
            dynamic_password, _ = generate_dynamic_password(base_password, algorithm, time_format)

            if dynamic_password and dynamic_password != password:
                return jsonify({"error": "Invalid password."}), 401

            return redirect('/current-state')
        else:
            return jsonify({"error": "Invalid username or password."}), 401

    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {str(e)}"}), 500
    
@app.route('/current-state')
def home():
    """
    Render the HTML page with the current lock status.
    """
    return render_template('lock_control.html', status=lock_state)
    

@app.route('/unlock', methods=['POST'])
def unlock():
    requests.get('http://192.168.1.2/fetch_for_cL20220206Abj01?dDCM=MANUALLY%20ON')
    """
    Set the lock state to 'Unlocked'.
    """
    global lock_state
    lock_state = "Unlocked"
    return render_template('lock_control.html', status=lock_state)

@app.route('/lock', methods=['POST'])
def lock():
    requests.get('http://192.168.1.2/fetch_for_cL20220206Abj01?dDCM=MANUALLY%20OFF')
    """
    Set the lock state to 'Locked'.
    """
    global lock_state
    lock_state = "Locked"
    return render_template('lock_control.html', status=lock_state)


# @app.route('/password', methods=['GET'])
# def get_dynamic_password():
#     username = request.args.get('username')
#     print(username)
#     password = request.args.get('password')
#     print(password)

#     if not username or not password:
#         return jsonify({"error": "Username and password are required."}), 400

#     conn = sqlite3.connect('users.db')
#     cursor = conn.cursor()
#     cursor.execute("SELECT hashed_password, algorithm, time_format FROM users WHERE username = ?", (username,))
#     row = cursor.fetchone()
#     print(row)
#     conn.close()

#     if row and hash_password(password) == row[0]:
#         base_password = password  # Since password is validated
#         algorithm = row[1]
#         time_format = row[2]
#         dynamic_password, _ = generate_dynamic_password(base_password, algorithm, time_format)
#         return jsonify({"dynamic_password": dynamic_password}), 200
#     else:
#         return jsonify({"error": "Invalid username or password."}), 401


@app.route('/time', methods=['GET'])
def get_server_time():
    current_time = datetime.now().isoformat()
    return jsonify({"server_time": current_time}), 200

@app.route('/security-question', methods=['GET','POST'])
def security_question():
    if request.method == 'GET':
        return render_template('security_question.html')
    
    elif request.method == 'POST':
        username = request.form['username']
        with sqlite3.connect('users.db') as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT security_question FROM users WHERE username = ?", (username,))
            row = cursor.fetchone()
        
        if row:
            question = row[0]
            return render_template('security_question.html', question=question, username=username)
        else:
            jsonify({"error": "username not found."}), 400
            return redirect('/security-question')

@app.route('/verify-security-answer', methods=['POST'])
def verify_security_answer():
    username = request.form['username']
    answer = request.form['answer']

    with sqlite3.connect('users.db') as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT security_answer FROM users WHERE username = ?", (username,))
        row = cursor.fetchone()

    if row and row[0].lower() == answer.lower():
        jsonify({"correct!": "Proceed to reset your password."})
        return redirect('/reset-password')
    else:
        jsonify({"error": "Incorrect answer. Please try again."}), 400
        return redirect('/reset-password')
        

@app.route('/reset-password', methods=['GET','POST'])
def reset_password():
    if request.method == 'GET':
        return render_template('reset_password.html')
    
    if request.method == 'POST':
        username = request.form.get('username')
        base_password = request.form.get('password')
        algorithm = request.form.get('algorithm', '1')
        time_format = request.form.get('time_format', '24') 

        if not username or not base_password:
            return jsonify({"error": "Username and password are required."}), 400
            
        if is_common_password(base_password):
            return jsonify({"Warning": "Your password is found in the common passwords list. Please choose a stronger password."}), 400
        else:
            if not is_valid_password(base_password):
                return jsonify({"error": "Password must meet security requirements."}), 400
        
        hashed_password = hash_password(base_password)

        try:
            conn = sqlite3.connect('users.db')
            cursor = conn.cursor()
            cursor.execute(
                "update users SET hashed_password = ?, algorithm = ?, time_format = ? WHERE username = ?",
                (hashed_password, algorithm, time_format, username))
            
            if cursor.rowcount == 0:  # Check if any rows were updated
                conn.close()
                return jsonify({"error": "Username does not exist."}), 404
            conn.commit()
            conn.close()
        except Exception as e:
            return jsonify({"error": str(e)}), 500

        dynamic_password, _ = generate_dynamic_password(base_password, algorithm, time_format)
        return render_template('signup_success.html', username=username, dynamic_password=dynamic_password), 201


@app.route("/logout", methods =["GET"])
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
