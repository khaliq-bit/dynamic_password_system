from flask import Flask, render_template, request, redirect, url_for, flash
from rocku_dynamic_passwd import (generate_dynamic_password, main)
app = Flask(__name__)
app.secret_key = "your_secret_key"

# Simulated database
users = {}


# Helper function to validate passwords
# def generate_dynamic_password(password):
#     import re
#     pattern = r"^(?=.*[A-Za-z])(?=.*\d)(?=.*[!@#$%^&*()_+=-]).{6,}$"
#     return re.match(pattern, password)


# Route for the signup page
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        base_password = request.form['basePassword']
        security_question = request.form['securityQuestion']
        security_answer = request.form['securityAnswer']
        time_interval = request.form['timeInterval']
        time_format = request.form.get('timeFormat', None)

        if base_password:
            main(base_password)
            

        # Validate the base password
        if not generate_dynamic_password(base_password,):
            flash("Password must be at least 6 characters long and include special characters, digits, and letters.")
            return redirect(url_for('signup'))

        # Save user details to "database"
        users['user'] = {
            'base_password': base_password,
            'security_question': security_question,
            'security_answer': security_answer,
            'time_interval': time_interval,
            'time_format': time_format,
        }

        flash("Signup successful! You can now login.")
        return redirect(url_for('login'))

    return render_template('signup.html')


# Route for the login page
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        login_password = request.form['loginPassword']

        # Dummy check for password; replace with dynamic password logic
        if 'user' in users and login_password == users['user']['base_password']:
            flash("Login successful!")
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid password. Please try again.")

    return render_template('login.html')


# Route for password reset
@app.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    if request.method == 'POST':
        security_question_answer = request.form['securityQuestionAnswer']
        new_password = request.form['newPassword']

        # Verify security question answer
        if 'user' in users and security_question_answer == users['user']['security_answer']:
            if validate_password(new_password):
                users['user']['base_password'] = new_password
                flash("Password reset successful! You can now login.")
                return redirect(url_for('login'))
            else:
                flash("New password does not meet requirements.")
        else:
            flash("Invalid answer to the security question.")

    return render_template('reset_password.html')


# Route for a dashboard (placeholder)
@app.route('/dashboard')
def dashboard():
    return "Welcome to your dashboard!"


if __name__ == '__main__':
    app.run(debug=True)
