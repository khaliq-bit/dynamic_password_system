import sqlite3

def get_database_connection():
    conn = sqlite3.connect("user_data.db")
    return conn

def initialize_database():
    conn = get_database_connection()
    cursor = conn.cursor()  

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        base_password TEXT NOT NULL,
        security_question TEXT NOT NULL,
        security_answer TEXT NOT NULL
    );
    """)
    conn.commit()
    conn.close()
