from flask import Flask, request, render_template_string

app = Flask(__name__)

# Variable to track the lock state
lock_state = "Locked"

# Your HTML as a template string
html_template = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FRONT DOOR</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Arial', sans-serif;
        }

        body {
            background: linear-gradient(to right, #4facfe, #00f2fe);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-attachment: fixed;
            overflow: hidden;
        }

        .container {
            position: relative;
            text-align: center;
            background-color: rgba(255, 255, 255, 0.9);
            padding: 40px 50px;
            border-radius: 20px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            width: 350px;
            transition: transform 0.3s ease;
        }

        .container:hover {
            transform: scale(1.05);
        }

        h1 {
            font-size: 28px;
            color: #333;
            margin-bottom: 30px;
            font-weight: 700;
            letter-spacing: 1px;
            text-transform: uppercase;
            animation: fadeIn 2s ease-in-out;
        }

        .btn {
            width: 100%;
            padding: 15px;
            font-size: 18px;
            color: white;
            border: none;
            border-radius: 50px;
            cursor: pointer;
            margin-bottom: 20px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .btn:active {
            transform: translateY(4px);
        }

        .btn.unlock {
            background: #3ecf8e;
            box-shadow: 0 8px 10px rgba(62, 207, 142, 0.5);
        }

        .btn.lock {
            background: #f44336;
            box-shadow: 0 8px 10px rgba(244, 67, 54, 0.5);
        }

        .btn.unlock:hover {
            background: #33b77f;
        }

        .btn.lock:hover {
            background: #e53935;
        }

        .status {
            margin-top: 20px;
            font-size: 20px;
            font-weight: 600;
            color: #555;
            animation: fadeIn 2s ease-in-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        body {
            animation: backgroundAnimate 10s infinite alternate;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>FRONT DOOR</h1>
        <form method="POST" action="/unlock">
            <button type="submit" class="btn unlock">Unlock Door</button>
        </form>
        <form method="POST" action="/lock">
            <button type="submit" class="btn lock">Lock Door</button>
        </form>
        <div class="status">
            Current Status: {{ status }}
        </div>
    </div>

</body>
</html>
"""

@app.route('/')
def index():
    """
    Render the HTML page with the current lock status.
    """
    return render_template_string(html_template, status=lock_state)

@app.route('/unlock', methods=['POST'])
def unlock():
    """
    Set the lock state to 'Unlocked'.
    """
    global lock_state
    lock_state = "Unlocked"
    return render_template_string(html_template, status=lock_state)

@app.route('/lock', methods=['POST'])
def lock():
    """
    Set the lock state to 'Locked'.
    """
    global lock_state
    lock_state = "Locked"
    return render_template_string(html_template, status=lock_state)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
