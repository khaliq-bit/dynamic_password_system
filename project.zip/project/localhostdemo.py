import hashlib
from datetime import datetime, timedelta
import re
import time

# Function to load common passwords from a file
def load_common_passwords(file_path):
    try:
        with open(file_path, "r",encoding="latin-1") as file:
            return set(line.strip() for line in file)
    except FileNotFoundError:
        print("Password file not found. Please check the file path.")
        return set()

# Load common passwords from your specified .txt file
common_passwords = load_common_passwords(r"C:\Users\MSI\Desktop\project\rockyou.txt")


# Function to generate dynamic password
def generate_dynamic_password(base_password, choice, time_format='24'):
    current_time = datetime.now()
    
    if choice == '1':  # Change every minute
        dynamic_password = f"{base_password}{current_time.minute}"
        next_change = current_time.replace(second=0, microsecond=0) + timedelta(minutes=1)
    elif choice == '2':  # Change every hour
        current_hour = current_time.strftime("%H") if time_format == '24' else current_time.strftime("%I")
        dynamic_password = f"{base_password}{current_hour}"
        next_change = current_time.replace(minute=0, second=0, microsecond=0) + timedelta(hours=1)
    elif choice == '3':  # Change every day of the week
        dynamic_password = f"{base_password}{current_time.strftime('%A')}"
        next_change = current_time.replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=1)
    
    return dynamic_password, next_change

# Function to hash the password
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

# Function to validate base password requirements
def is_valid_password(password):
    if len(password) < 6:
        return False
    if not re.search(r"[A-Z]", password):
        return False
    if not re.search(r"[a-z]", password):
        return False
    if not re.search(r"[0-9]", password):
        return False
    if not re.search(r"[!@#$%^&*()_+=-]", password):
        return False
    return True

# Function to check if the password is in the common passwords list
def is_common_password(password):
    return password in common_passwords

# Function to reset the password using security question
def reset_password():
    print("\nForgot Password: Answer the security question to reset your password.")
    answer = input(f"{security_question} ")
    if answer.lower() == security_answer.lower():
        while True:
            new_password = input("Enter your new base password (at least 6 characters, including special characters, digits, and letters): ")
            if is_valid_password(new_password):
                return new_password
            else:
                print("Password must meet the security requirements.")
    else:
        print("Incorrect answer to the security question.")
    return None

# Main function
def main():
    # Prompt the user to create a base password and set a security question
    while True:
        base_password = input("Enter your base password (at least 6 characters, including special characters, digits, and letters): ")
        
        if is_common_password(base_password):
            print("Warning: Your password is found in the common passwords list. Please choose a stronger password.")
            continue
            
        if is_valid_password(base_password):
            break
        else:
            print("Password must meet the security requirements.")
    
    global security_question, security_answer
    print("It is advised not to use your password directly for security reasons.")
    security_question = input("Set a security question for password recovery: ")
    security_answer = input("Answer to your security question: ")

    # User chooses the algorithm
    while True:
        print("\nChoose the algorithm for changing the dynamic password:")
        print("1. Change every minute")
        print("2. Change every hour")
        print("3. Change based on the day of the week")
        choice = input("Enter your choice (1/2/3): ")
        if choice in ('1', '2', '3'):
            break
        else:
            print("Invalid choice. Please select 1, 2, or 3.")

    time_format = '24'  # Default to 24-hour format
    if choice == '2':
        # Allow the user to choose the time format
        while True:
            print("\nChoose the time format for the hour-based password:")
            print("1. 24-hour format")
            print("2. 12-hour format")
            time_format_choice = input("Enter your choice (1/2): ")
            if time_format_choice == '1':
                time_format = '24'
                break
            elif time_format_choice == '2':
                time_format = '12'
                break
            else:
                print("Invalid choice. Please select 1 or 2.")
    
    # Generate the initial dynamic password
    dynamic_password, next_change = generate_dynamic_password(base_password, choice, time_format)
    hashed_password = hash_password(dynamic_password)

    # Display the current dynamic password once
    print(f"\nYour current dynamic password is: {dynamic_password}")

    retry_limit = 3  # Set retry limit
    attempts = 0  # Initialize attempt counter

    while True:
        # Check if the password needs updating due to time interval change
        if datetime.now() >= next_change:
            dynamic_password, next_change = generate_dynamic_password(base_password, choice, time_format)
            hashed_password = hash_password(dynamic_password)
            attempts = 0  # Reset attempts when the password changes
            print("\nThe dynamic password has changed. Please log in with the new dynamic password.")
            print(f"Your new dynamic password is: {dynamic_password}")

        # Provide option to enter password or reset it
        user_input = input("Enter the current dynamic password (or type 'forgot' to reset password): ")
        
        if user_input.lower() == "forgot":
            new_password = reset_password()
            if new_password:
                base_password = new_password
                dynamic_password, next_change = generate_dynamic_password(base_password, choice, time_format)
                hashed_password = hash_password(dynamic_password)
                print("Password reset successful! Your new dynamic password is:", dynamic_password)
                print("Avoid using previous passwords for security reasons.")
            continue

        attempts += 1

        if user_input == dynamic_password:
            print("Login successful!")
            break
        else:
            print("Incorrect password. Please try again.")
            if attempts >= retry_limit:
                print("Maximum retry limit reached. Access locked.")
                break

        # Pause briefly before allowing the next attempt
        time.sleep(2)

if __name__ == "__main__":
    main()
